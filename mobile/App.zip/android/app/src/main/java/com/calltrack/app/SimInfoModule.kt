package com.calltrack.app

import android.content.Context
import android.os.Build
import android.telephony.SubscriptionManager
import com.facebook.react.bridge.Arguments
import com.facebook.react.bridge.Promise
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.ReactContextBaseJavaModule
import com.facebook.react.bridge.ReactMethod

class SimInfoModule(private val reactContext: ReactApplicationContext) :
    ReactContextBaseJavaModule(reactContext) {

    override fun getName() = "SimInfoModule"

    @ReactMethod
    fun getAvailableSims(promise: Promise) {
        try {
            val sm = reactContext.getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE) as? SubscriptionManager
            val result = Arguments.createArray()
            if (sm == null || Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP_MR1) {
                promise.resolve(result); return
            }
            (sm.activeSubscriptionInfoList ?: emptyList()).forEach { info ->
                Arguments.createMap().apply {
                    putInt   ("subscriptionId", info.subscriptionId)
                    putInt   ("slotIndex",      info.simSlotIndex)
                    putString("displayName",    info.displayName?.toString() ?: "SIM ${info.simSlotIndex + 1}")
                    putString("carrierName",    info.carrierName?.toString() ?: "")
                    putString("number",         info.number ?: "")
                    result.pushMap(this)
                }
            }
            promise.resolve(result)
        } catch (e: Exception) {
            promise.reject("SIM_ERROR", e.message ?: "Failed to read SIM info")
        }
    }
}
