package com.calltrack.app

import android.content.Context
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import com.facebook.react.bridge.Arguments
import com.facebook.react.bridge.Promise
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.ReactContextBaseJavaModule
import com.facebook.react.bridge.ReactMethod

class CallLogModule(private val reactContext: ReactApplicationContext) :
    ReactContextBaseJavaModule(reactContext) {

    init { PhoneStateReceiver.reactContext = reactContext }

    override fun getName() = "CallLogModule"

    @ReactMethod
    fun checkPermissions(promise: Promise) {
        val phone   = ContextCompat.checkSelfPermission(reactContext, android.Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED
        val callLog = ContextCompat.checkSelfPermission(reactContext, android.Manifest.permission.READ_CALL_LOG)   == PackageManager.PERMISSION_GRANTED
        promise.resolve(phone && callLog)
    }

    @ReactMethod
    fun setTrackedSim(subscriptionId: Int) {
        PhoneStateReceiver.trackedSubId = subscriptionId
    }

    /** Called from JS on every app foreground to pick up any call that happened while closed */
    @ReactMethod
    fun getPendingCall(promise: Promise) {
        try {
            val prefs = reactContext.getSharedPreferences("CallTrackPrefs", Context.MODE_PRIVATE)
            if (!prefs.getBoolean("has_pending", false)) {
                promise.resolve(null)
                return
            }
            val map = Arguments.createMap().apply {
                putString("contactNumber", prefs.getString("pending_number",    "") ?: "")
                putString("contactName",   prefs.getString("pending_name",      "") ?: "")
                putString("callType",      prefs.getString("pending_type",      "") ?: "")
                putInt   ("duration",      prefs.getInt   ("pending_duration",  0))
                putString("timestamp",     prefs.getString("pending_timestamp", "") ?: "")
            }
            // Clear so we don't show the same call twice
            prefs.edit().putBoolean("has_pending", false).apply()
            promise.resolve(map)
        } catch (e: Exception) {
            promise.resolve(null)
        }
    }

    @ReactMethod fun addListener(eventName: String) {}
    @ReactMethod fun removeListeners(count: Int) {}
}
