package com.calltrack.app

import android.app.ActivityManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.provider.CallLog
import android.telephony.TelephonyManager
import com.facebook.react.bridge.Arguments
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.modules.core.DeviceEventManagerModule

class PhoneStateReceiver : BroadcastReceiver() {

    companion object {
        private var lastState  = TelephonyManager.CALL_STATE_IDLE
        private var callStart  = 0L
        private var isIncoming = false
        private var savedNum   = ""

        const val CHANNEL_ID = "calltrack_calls"

        var reactContext: ReactApplicationContext? = null
        var trackedSubId: Int = -1
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != "android.intent.action.PHONE_STATE") return

        // SIM filtering
        val subId = intent.getIntExtra("android.telephony.extra.SUBSCRIPTION_INDEX", -1)
            .let { if (it == -1) intent.getIntExtra("subscription", -1) else it }
        if (trackedSubId != -1 && subId != -1 && subId != trackedSubId) return

        val stateStr = intent.getStringExtra(TelephonyManager.EXTRA_STATE) ?: return
        val number   = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER) ?: ""

        val state = when (stateStr) {
            TelephonyManager.EXTRA_STATE_RINGING -> TelephonyManager.CALL_STATE_RINGING
            TelephonyManager.EXTRA_STATE_OFFHOOK -> TelephonyManager.CALL_STATE_OFFHOOK
            else                                  -> TelephonyManager.CALL_STATE_IDLE
        }

        handleStateChange(context, lastState, state, number)
        lastState = state
    }

    private fun handleStateChange(context: Context, prev: Int, state: Int, number: String) {
        val IDLE     = TelephonyManager.CALL_STATE_IDLE
        val RINGING  = TelephonyManager.CALL_STATE_RINGING
        val OFFHOOK  = TelephonyManager.CALL_STATE_OFFHOOK
        when {
            prev == IDLE    && state == RINGING  -> { isIncoming = true;  savedNum = number; callStart = System.currentTimeMillis() }
            prev == IDLE    && state == OFFHOOK  -> { isIncoming = false; callStart = System.currentTimeMillis() }
            prev == RINGING && state == OFFHOOK  -> { callStart = System.currentTimeMillis() }
            state == IDLE   && prev != IDLE      -> {
                val approxDur  = ((System.currentTimeMillis() - callStart) / 1000).toInt()
                val callType   = when { prev == RINGING -> "missed"; isIncoming -> "incoming"; else -> "outgoing" }
                // Delay 1.5s so CallLog has time to write the entry
                Handler(Looper.getMainLooper()).postDelayed({ onCallEnded(context, callType, approxDur) }, 1500)
            }
        }
    }

    private fun onCallEnded(context: Context, fallbackType: String, fallbackDur: Int) {
        val sdf = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", java.util.Locale.US)
        sdf.timeZone = java.util.TimeZone.getTimeZone("UTC")

        var number    = savedNum
        var name      = ""
        var callType  = fallbackType
        var duration  = fallbackDur
        var timestamp = sdf.format(java.util.Date())

        // Read the freshest call from CallLog
        try {
            context.contentResolver.query(
                CallLog.Calls.CONTENT_URI,
                arrayOf(CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME,
                        CallLog.Calls.DATE,   CallLog.Calls.DURATION, CallLog.Calls.TYPE),
                null, null, "${CallLog.Calls.DATE} DESC"
            )?.use { cur ->
                if (cur.moveToFirst()) {
                    number    = cur.getString(0) ?: savedNum
                    name      = cur.getString(1) ?: ""
                    callType  = when (cur.getInt(4)) {
                        CallLog.Calls.INCOMING_TYPE -> "incoming"
                        CallLog.Calls.OUTGOING_TYPE -> "outgoing"
                        CallLog.Calls.MISSED_TYPE   -> "missed"
                        CallLog.Calls.REJECTED_TYPE -> "rejected"
                        else                         -> fallbackType
                    }
                    duration  = cur.getInt(3)
                    timestamp = sdf.format(java.util.Date(cur.getLong(2)))
                }
            }
        } catch (_: Exception) {}

        // ── Always persist to SharedPrefs so JS can read it on next launch ──
        context.getSharedPreferences("CallTrackPrefs", Context.MODE_PRIVATE).edit()
            .putString("pending_number",    number)
            .putString("pending_name",      name)
            .putString("pending_type",      callType)
            .putInt   ("pending_duration",  duration)
            .putString("pending_timestamp", timestamp)
            .putBoolean("has_pending",      true)
            .apply()

        val rc = reactContext
        if (rc != null && isAppForeground(context)) {
            // App is open & visible → emit directly to JS (shows AfterCallModal instantly)
            val map = Arguments.createMap().apply {
                putString("contactNumber", number)
                putString("contactName",   name)
                putString("callType",      callType)
                putInt   ("duration",      duration)
                putString("timestamp",     timestamp)
            }
            try {
                rc.getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter::class.java)
                  .emit("onCallEnded", map)
                return // handled via JS, no need to launch activity
            } catch (_: Exception) {}
        }
        // App is closed or in background → launch it so the popup appears
        launchApp(context)
    }

    private fun isAppForeground(context: Context): Boolean {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager ?: return false
        return am.runningAppProcesses?.any {
            it.importance == ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND &&
            it.processName == context.packageName
        } == true
    }

    private fun launchApp(context: Context) {
        // Bring the app to foreground — App.js reads SharedPrefs and shows the AfterCallModal popup
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_SINGLE_TOP or
                    Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
            putExtra("from_call_end", true)
        }
        try { context.startActivity(intent) } catch (_: Exception) {}
    }
}
