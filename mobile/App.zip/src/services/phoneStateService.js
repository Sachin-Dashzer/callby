import { NativeModules, DeviceEventEmitter, PermissionsAndroid, Platform } from 'react-native';

const { CallLogModule } = NativeModules;

export async function requestCallPermissions() {
  if (Platform.OS !== 'android') return false;
  try {
    const result = await PermissionsAndroid.requestMultiple([
      PermissionsAndroid.PERMISSIONS.READ_PHONE_STATE,
      PermissionsAndroid.PERMISSIONS.READ_CALL_LOG,
    ]);
    return (
      result[PermissionsAndroid.PERMISSIONS.READ_PHONE_STATE] === PermissionsAndroid.RESULTS.GRANTED &&
      result[PermissionsAndroid.PERMISSIONS.READ_CALL_LOG] === PermissionsAndroid.RESULTS.GRANTED
    );
  } catch {
    return false;
  }
}

// Returns an unsubscribe function
export function onCallEnded(callback) {
  const sub = DeviceEventEmitter.addListener('onCallEnded', callback);
  return () => sub.remove();
}
